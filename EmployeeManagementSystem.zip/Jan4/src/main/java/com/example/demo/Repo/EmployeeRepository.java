package com.example.demo.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;

@Service
public interface EmployeeRepository extends JpaRepository<Employee,Long>
{

}
